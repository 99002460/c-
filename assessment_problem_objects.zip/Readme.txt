/*
* In this problem you are expected to implement a solution 
* with certain operations on collection of Objects in 2D space
* IObject as an abstract class 
*    - suitable constructor
*    - suitable pure virtual like distance from origin, quadrant belongs to  
*    - use enum for list of Quadrants   
* An IObject can be specialized as WObject as follows (i.e. Weighted Object)
*    - attributes - x, y, weight 
*    - suitable constructor(s) for derived class
*    - override pure virtual functions ,i.e distance from origin, quadrant belongs to.
* You must strongly exhibhit polymorphic design aspects with above classes
* Use upcasted pointers/references and dynamic binding to demonstrate runtime polymorphism
* Implement another class say ObjectDb with collection of WObject instances
* (derived class ) using suitable data set (right STL container)
* Implement some operations on collection of Objects as per following test calls
*    - addObject(3, 4, 100)
*    - removeObject(5,6);              
*      //Assuming no two Boxes on same coordinates 
*      //remove only if both x,y matches
*    - countAll()
*    - findMinWeight()
*    - findMaxDistanceFromOrigin()          //distance of farthest point
*    - countObjectsByQuadrant(Q3)
*    - countObjectsOnCircleBoundary(5)      //same radius, distanceFrom Origin
* Please provide optimal business logic in specified functions without any redundancy
* Core functions should be detached from console i/o and suitable for testable approach
* Please implement a simple test plan with suitable function calls in main 
* Provide solution in terms of multiple files with clean hierarchy of
* header, source files 
* Please add class diagram if time permits at end
* Follow the best practices of C++ & clean coding practices while implementing
* Please follow good coding style and meaningful names
* Your code shouldn't be crashed and no memory leaks/heap errors are expected from your code
* Your code will be validated against following code quality parameters
  * Code Style - googlestyle (clang-format/AStyle)
  * Static Analysis - cppcheck.
  * Heap Analysis - valgrind
* Please add class diagram at end
* Try to demonstrate RTTI features like dynamic_cast, typeid (this may not relate with 
* collection of objects or given test codelisted below, can be independent code) 
*/
